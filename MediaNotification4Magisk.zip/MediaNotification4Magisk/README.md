<p align="center">
<b> Medianotification4Magisk </b><br>
</p>

## Module Explanation:
A very simple module just to make MediaNotification work as a system app systemlessly .It'll simply inject a folder with the apk into the path: /system/app. 


## Requirements: 
- Android 5.0+ (Magisk requirement).
- Magisk v14+ (Manager and SU).
